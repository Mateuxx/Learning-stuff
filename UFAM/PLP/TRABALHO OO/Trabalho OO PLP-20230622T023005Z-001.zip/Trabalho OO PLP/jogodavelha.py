from enum import Enum

class Casa(Enum):
    VAZIA = 0
    JOGADOR1 = 1
    JOGADOR2 = 2

class JogoDaVelha:
    def __init__(self):
        self.matriz = [[Casa.VAZIA] * 3 for _ in range(3)]

    def exibir_matriz(self):
        for linha in self.matriz:
            print("|".join(str(casa.value) for casa in linha))
            print("-" * 5)

    def realizar_jogada(self, jogador, linha, coluna):
        if self.matriz[linha][coluna] == Casa.VAZIA:
            self.matriz[linha][coluna] = jogador
        else:
            print("Essa posição já está ocupada. Tente novamente.")

    def verificar_vitoria(self):
        for linha in self.matriz:
            if linha[0] == linha[1] == linha[2] != Casa.VAZIA:
                return True

        for coluna in range(3):
            if self.matriz[0][coluna] == self.matriz[1][coluna] == self.matriz[2][coluna] != Casa.VAZIA:
                return True

        if (self.matriz[0][0] == self.matriz[1][1] == self.matriz[2][2] != Casa.VAZIA) or \
                (self.matriz[0][2] == self.matriz[1][1] == self.matriz[2][0] != Casa.VAZIA):
            return True

        return False

    def jogar(self):
        jogador_atual = Casa.JOGADOR1
        jogadas = 0

        while True:
            self.exibir_matriz()

            linha = int(input("Digite o número da linha (0-2): "))
            coluna = int(input("Digite o número da coluna (0-2): "))

            self.realizar_jogada(jogador_atual, linha, coluna)
            jogadas += 1

            if self.verificar_vitoria():
                self.exibir_matriz()
                print(f"Jogador {jogador_atual.value} venceu!")
                break

            if jogadas == 9:
                self.exibir_matriz()
                print("O jogo empatou!")
                break

            jogador_atual = Casa.JOGADOR2 if jogador_atual == Casa.JOGADOR1 else Casa.JOGADOR1

jogo = JogoDaVelha()
jogo.jogar()