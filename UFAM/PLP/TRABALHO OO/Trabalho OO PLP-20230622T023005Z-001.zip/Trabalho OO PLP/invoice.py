class Invoice:
    def __init__(self, NumItem, DescricaoItem, QuantidadeItem, PrecoItem):
        self.NumItem = NumItem
        self.DescricaoItem = DescricaoItem
        self.QuantidadeItem = QuantidadeItem if QuantidadeItem > 0 else 0
        self.PrecoItem = PrecoItem if PrecoItem > 0.0 else 0.0

    def setNumItem(self, NumItem):
        self.NumItem = NumItem
        
    def setDescricaoItem(self, DescricaoItem):
        self.DescricaoItem = DescricaoItem

    def setQuantidadeItem(self, QuantidadeItem):
        self.QuantidadeItem = QuantidadeItem       

    def setPrecoItem(self, PrecoItem):
        self.PrecoItem = PrecoItem

    def getNumItem(self):
        return self.NumItem
        
    def getDescricaoItem(self):
        return self.DescricaoItem

    def getQuantidadeItem(self):
        return self.QuantidadeItem
        
    def getPrecoItem(self):
        return self.PrecoItem
        
    def getInvoiceAmount(self):
        return self.PrecoItem * self.QuantidadeItem


comanda = Invoice(1, "Dolar: Moeda do país que vive a custas de guerras e crises economicas ao redor do mundo", 1956 , 4.78)
print(comanda.getDescricaoItem())
print(comanda.getInvoiceAmount())

comanda.setDescricaoItem("HONDA CIVIC 2018")
comanda.setPrecoItem(95.891)
comanda.setQuantidadeItem(3)
print(comanda.getDescricaoItem())
print(comanda.getInvoiceAmount())