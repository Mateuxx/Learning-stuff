import math

class Complex:

    def __init__(self, real=0, imaginario=0):
        self.__real = real
        self.__imaginario = imaginario
    
    def getReal(self):
        return self.__real

    def getImaginario(self):
        return self.__imaginario
    
    def getModulo(self):
        return math.sqrt(pow(self.__real, 2) + pow(self.__imaginario, 2))

    def getCos(self):
        return self.__imaginario/self.getModulo()
    
    def getSen(self):
        return self.__real/self.getModulo()
    
    def getAngulo(self):
        rad = math.atan2(self.getSen(), self.getCos())
        return math.degrees(rad)
    
    def getInverso(self):
        return Complex(-self.__real, -self.__imaginario)
    
    def getSoma(self, a):
        real = self.__real + a.__real
        imaginario = self.__imaginario + a.__imaginario
        return Complex(real, imaginario)

    def getSub(self, a):
        real = self.__real - a.__real
        imaginario = self.__imaginario - a.__imaginario
        return Complex(real, imaginario)
    
    def getMult(self, a):
        real = self.__real * a.getReal() - self.__imaginario * a.getImaginario()
        imaginario = self.__real * a.getImaginario() + self.__imaginario * a.getReal()
        return Complex(real, imaginario)
    
    def getDiv(self, a):
        divisor = a.getReal()**2 + a.getImaginario()**2
        real = (self.__real * a.getReal() + self.__imaginario * a.getImaginario()) / divisor
        imaginario = (self.__imaginario * a.getReal() - self.__real * a.getImaginario()) / divisor
        return Complex(real, imaginario)

    def ehIgual(self, a):
        return True if self.__real == a.__real and self.__imaginario == a.__imaginario else False

    def toString(self):
        return f"({self.__real}, {self.__imaginario})"
    
def main():
    # Criando números complexos
    c1 = Complex(2, 3)
    c2 = Complex(1, -2)
    c3 = Complex(4)

    # Obtendo informações dos números complexos
    print("Número complexo c1:")
    print("Parte Real:", c1.getReal())
    print("Parte Imaginária:", c1.getImaginario())
    print("Módulo:", c1.getModulo())
    print("Cosseno:", c1.getCos())
    print("Seno:", c1.getSen())
    print("Ângulo em graus:", c1.getAngulo())
    print("Inverso Aditivo:", c1.getInverso().toString())
    print()

    # Realizando operações com números complexos
    print("Operações com números complexos:")
    print("Soma de c1 e c2:", c1.getSoma(c2).toString())
    print("Subtração de c1 e c2:", c1.getSub(c2).toString())
    print("Multiplicação de c1 e c2:", c1.getMult(c2).toString())
    print("Divisão de c1 por c2:", c1.getDiv(c2).toString())
    print()

    # Verificando igualdade entre números complexos
    print("Comparação entre números complexos:")
    print("c1 é igual a c2?", c1.ehIgual(c2))
    print("c1 é igual a c3?", c1.ehIgual(c3))
    print()

    # Convertendo números complexos em string
    print("Representação em string dos números complexos:")
    print("c1:", c1.toString())
    print("c2:", c2.toString())
    print("c3:", c3.toString())


# Executando a função main
main()