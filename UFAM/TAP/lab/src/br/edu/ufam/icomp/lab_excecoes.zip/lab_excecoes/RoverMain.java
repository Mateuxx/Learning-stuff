package br.edu.ufam.icomp.lab_excecoes;

public class RoverMain {
	public static void main(String[] args) {
        // Testando a criação de uma Coordenada válida
        Coordenada c1 = new Coordenada(10, 20, 3);
        System.out.println("Coordenada 1: " + c1);
}
}